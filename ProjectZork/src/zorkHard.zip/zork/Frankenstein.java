package zork;

/**
 * sub class of monster
 *
 * <hr>
 * Date created: Apr 26, 2018
 * <hr>
 * @author Roland Patrick Mahe
 */
public class Frankenstein extends Monster{
					
	
	/**
	 * Constructor        
	 *
	 * <hr>
	 * Date created: Apr 26, 2018 
	 *
	 * 
	 */
	public Frankenstein()
	{
		super(20, 5, "Frankenstein");
	}
}
