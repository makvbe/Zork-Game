package zork;

/**
 * sub class for monster
 *
 * <hr>
 * Date created: Apr 26, 2018
 * <hr>
 * @author Roland Patrick Mahe
 */
public class KingKong extends Monster{
	
	
	/**
	 * Constructor        
	 *
	 * <hr>
	 * Date created: Apr 26, 2018 
	 *
	 * 
	 */
	public KingKong()
	{
		super(30, 15, "King Kong");
	}
}
