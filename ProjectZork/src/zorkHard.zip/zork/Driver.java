/**
 * ---------------------------------------------------------------------------
 * File name: Driver.java
 * Project name: ProjectZork
 * ---------------------------------------------------------------------------
 * Creator's name and email: Roland Patrick Mahe, maher1@etsu.edu
 * Course:  CSCI 1260
 * Creation Date: Apr 23, 2018
 * ---------------------------------------------------------------------------
 */
package zork;
import java.util.Random;
import java.util.Scanner;

/**
 * Drives the game
 *
 * <hr>
 * Date created: Apr 23, 2018
 * <hr>
 * @author Roland Patrick Mahe
 */
public class Driver
{
	public static Game g1;
	public static Monster currentMonster;
	
	public static void main(String[] args)
	{
		Scanner kb = new Scanner(System.in);
		Random rand = new Random(); //creates object of random class 
		int columns = rand.nextInt(6) + 5; //invokes nextInt method to assign random number in 5-10 range to int num
		int rows = rand.nextInt(6) + 5;
		boolean exited = false;
		g1 = new Game(rows, columns);
		showGrid();
		System.out.println("Your choices for movement are 'go north' , 'go east' , 'go south' , and 'go west'");
		do {
			movePlayer(getDirection());
			showGrid();
			showHealth();
			
			String[] player = g1.findPlayer().split ("\\|");//split the player location string (formatted "Y|X")
			int y = Integer.parseInt(player[0]);//assign the row location to y
			int x = Integer.parseInt (player[1]);//assign the column location to x
			
			
			if(g1.getDungeon ( ).getRooms ( )[y][x].getholdsWeapon ( ))
			{
			    System.out.println("There is a weapon in this room! Do you want to pick up the weapon?");
			    pickUp(kb.nextLine());
			}
			
			
			if(g1.actionRequired())
			{
				do {
					battleRun(getFightOrRun());
				}while(g1.actionRequired ( ));
			}
			
			if(g1.canExit ( ))
			{
				System.out.println("\nExiting the dungeon..." +
								   "\n\nCONGLATURATION !!!" +
								   "\n\nYOU HAVE COMPLETED A GREAT GAME." +
								   "\nAND PROOVED THE JUSTICE OF OUR CULTURE." +
								   "\nNOW GO AND REST OUR HEROES !");
				exited = true;
				g1.exitDungeon ( );
			}
		}while(g1.getPlayer ( ).getHealth() > 0 && !exited);
		
		kb.close ( );
	}//end main
	
	/**
	 * gets the direction that the player wants to move       
	 *
	 * <hr>
	 * Date created: Apr 26, 2018
	 *
	 * <hr>
	 * @return
	 */
	public static String getDirection()
	{
		Scanner kb = new Scanner(System.in);

		String userInput = "";
		boolean validChoice;
		
		do
		{
		    try
		    { 
		        System.out.println("Make your move: ");

		        userInput = kb.nextLine().toUpperCase();

		        if(!userInput.equals("GO NORTH") && !userInput.equals("GO EAST") && !userInput.equals("GO SOUTH") && !userInput.equals("GO WEST"))
		        {
		            throw new Exception("That is an invalid entry. Please type your choice again!");
		        }
		        validChoice = true;
		    }
		    catch(Exception ex)
		    {
		        System.out.println(ex.getMessage());
		        validChoice = false;
		    }
		}while(validChoice == false);
		
		return userInput;
	}
	
	/**
	 * moves the player       
	 *
	 * <hr>
	 * Date created: Apr 26, 2018
	 *
	 * <hr>
	 * @param direction
	 */
	public static void movePlayer(String direction)
	{
		switch(direction)
		{
			case "GO NORTH":
				try {
					g1.goNorth();
				}
				catch(Exception ex) {
					System.out.println("You can't move north right now!");
				}
				break;
			case "GO EAST":
				try {
					g1.goEast();
				}
				catch(Exception ex) {
					System.out.println("You can't move east right now!");
				}
				break;
			case "GO SOUTH":
				try {
					g1.goSouth();
				}
				catch(Exception ex) {
					System.out.println("You can't move south right now!");
				}
				break;
			case "GO WEST":
				try {
					g1.goWest();
				}
				catch(Exception ex) {
					System.out.println("You can't move west right now!");
				}
				break;
		}
	}//end movePlayer

	public static void pickUp(String userInput)
	{
		Scanner kb = new Scanner(System.in);//creating scanner object
		String[] player = g1.findPlayer().split ("\\|");//split the player location string (formatted "Y|X")
        int y = Integer.parseInt(player[0]);//assign the row location to y
        int x = Integer.parseInt (player[1]);//assign the column location to x
	    userInput = userInput.toUpperCase ( );//converting userinput to upper case
	    boolean validInput = false;//a boolean that will tell whether or not valid input was given
	    do {
	        if(userInput.equals("YES"))//if user enters yes
	        {
	            Weapon weapon = g1.getDungeon ( ).getRooms ( )[y][x].getWeapon ( );//get weapon in room and assign it to weapon
	            g1.pickUpWeapon (weapon);//pick up weapon
	            System.out.println("You picked up (a) " + weapon);//telling the user they picked up this weapon
	            validInput = true;//valid input was given
	        }
	        else if(userInput.equals ("NO"))//if user enters no
	        {
	            validInput = true;//valid input was given, but do nothing
	        }
	        else
	        {
	            System.out.println("I don't understand... Please enter 'yes' or 'no'");//telling the user i dont understand, since they entered something invalid
	            userInput = kb.nextLine().toUpperCase ( );//getting the users input again
	        }
	    }while(!validInput);//do while there isnt a valid input
	}
	
	/**
	 * Gets whether the player wants to fight or run         
	 *
	 * <hr>
	 * Date created: Apr 26, 2018
	 *
	 * <hr>
	 * @return
	 */
	public static String getFightOrRun()
	{
		Scanner kb = new Scanner(System.in);//creating new scanner object

		String userInput = "";//creating variable to userinput to be stored in
		boolean validChoice;//a boolean to store whether valid choice was given
		
		do
		{
		    try
		    { 
		    	String[] player = g1.findPlayer().split ("\\|");//split the player location string (formatted "Y|X")
		        int y = Integer.parseInt(player[0]);//assign the row location to y
		        int x = Integer.parseInt (player[1]);//assign the column location to x
		        currentMonster = g1.getDungeon ( ).getRooms ( )[y][x].getMonster ( );//current monster equals the monster in the players room
	    		System.out.println("\nThere is (a) " + currentMonster.getName ( ) + " in the room! \nDo you want to attack it or run away? (Type 'attack' or 'run'): ");

		        userInput = kb.nextLine().toUpperCase();//getting the users input and converting it to upper case

		        if(!userInput.equals("ATTACK") && !userInput.equals("RUN") )//if user inputs anything else besides attack or run...
		        {
		            throw new Exception("That is an invalid entry. Please type your choice again!");//tell them they entered something invalid and throw exception
		        }
		        validChoice = true;//valid choice is true
		        
		    }
		    catch(Exception ex)
		    {
		        System.out.println(ex.getMessage());//get message of exception
		        validChoice = false;//valid choice is false
		    }
		}while(validChoice == false);//while valid choice is false
		
		return userInput;
	}//end getFightOrRun
	
	/**
	 * Runs the battle     
	 *
	 * <hr>
	 * Date created: Apr 26, 2018
	 *
	 * <hr>
	 * @param userChoice
	 */
	public static void battleRun(String userChoice)
	{
		Random rand = new Random();//creating new random object
		int num = rand.nextInt(10) + 1;//num will be between 1 and 10 inclusively
		String[] player = g1.findPlayer().split ("\\|");//split the player location string (formatted "Y|X")
        int y = Integer.parseInt(player[0]);//assign the row location to y
        int x = Integer.parseInt (player[1]);//assign the column location to x
		switch(userChoice)
		{
			case "ATTACK"://if userChoice is attack

		        if(num <= 9)//90% chance to hit monster
		        {
		        	System.out.println("\nYou hit the monster for " + g1.getPlayer ( ).getDamage ( ) + " damage!");
		        	g1.attackMonster(currentMonster);//damage monster with players damage stat
		        }
		        else
		        {
		        	System.out.println("\nYou missed!");//tell the user they missed
		        }
		        
		        if(num <= 8)//80% chance for monster to hit player
		        {
		        	System.out.println("The monster hit you for " + currentMonster.getDamage ( ) + " damage!");
		        	g1.dmgPlayer (currentMonster);//damage player with currentMonsters damage stat
		        }
		        else 
		        {
		        	System.out.println("The monster missed!");//tell the user the monster missed
		        }
		        
		        System.out.println ("\nMonster health: " + currentMonster.getHealth ( ) + 
									"\nPlayer health: " + g1.getPlayer ( ).getHealth ( ) + "\n");//tell the userr the monsters health and their health
		        
		        if(g1.getPlayer ( ).getHealth ( ) <= 0)//if users health is less than or equal to 0 then...
		        {
		        	System.out.println("\nYou died!" +
		        					   "\nGAME OVER");//tell the user they died
		        	System.exit (0);//exit
		        }
		        else if(currentMonster.getHealth ( ) <= 0)//if monsters health is <= 0 then...
		        {
		        	g1.getDungeon ( ).getRooms ( )[y][x].setHoldsMonster (false);//players room no longer holds a monster
		        	System.out.println(g1.getDungeon() + "\n\nYou defeated the monster!");//tell the user they defeated the monster
		        }
		        
				break;
				
			case "RUN"://if the userChoice is run
				try
				{
					g1.runAway();//run away
					showGrid();//show grid
				}
				catch(Exception ex)//if the user fails to run away
				{
					System.out.println ("\nYou failed to run away!");//tell them
			        System.out.println("The monster hit you for " + currentMonster.getDamage ( ) + " damage!");//tell the user the monster hit them
			        g1.dmgPlayer (currentMonster);//the monster hits the player 100% of the time if they run away
				}
				break;
		}
	}//end battleRun(String userChoice)
	
	public static void showHealth()
	{
		System.out.println ("Player's Health: " + g1.getPlayer ( ).getHealth ( ));//show health
	}//end showHealth
	
	public static void showGrid()
	{
		System.out.println (g1.getDungeon());//show grid
	}//end showGrid()
}
