package zork;

/**
 * sub class for monster
 *
 * <hr>
 * Date created: Apr 26, 2018
 * <hr>
 * @author Roland Patrick Mahe
 */
public class Cyclops extends Monster{
	
	
	/**
	 * Constructor        
	 *
	 * <hr>
	 * Date created: Apr 26, 2018 
	 *
	 * 
	 */
	public Cyclops()
	{
		super(25, 5, "Cyclops");
	}
}
