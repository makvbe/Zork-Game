/**
 * ---------------------------------------------------------------------------
 * File name: package-info.java
 * Project name: ProjectZork
 * ---------------------------------------------------------------------------
 * Creator's name and email: Roland Patrick Mahe, maher1@etsu.edu
 * Course: CSCI 1260
 * Creation Date: Apr 23, 2018
 * ---------------------------------------------------------------------------
 */

/**
 * Enter type purpose here
 *
 * <hr>
 * Date created: Apr 23, 2018
 * <hr>
 * @author Roland Patrick Mahe
 */
package zork;